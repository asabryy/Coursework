package comp2402a2;
import java.util.List;


/**
 */
public class Tester {
	public static boolean testPart1(List<Integer> ell) {
		return true;
	}

	public static boolean testPart2(List<Integer> ell) {
		return true;
	}

	public static boolean testPart3(AbstractTable<Integer> ell) {
		return true;
	}

}
